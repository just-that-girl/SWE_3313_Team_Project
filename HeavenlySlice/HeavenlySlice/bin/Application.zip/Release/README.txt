TEST CUSTOMER LOGINS

Name : Adam Brown
Address : 101 Maple Hollow
Phone : 1111111111
Charge Account : Cash
Area Feature : near river

Name : Cindy Dirk
Address : 202 Oak Ridge
Phone : 2222222222
Charge Account : Cash
Area Feature : apartment

Name : Eddie Franklin
Address : 303 Pine Crest
Phone : 3333333333
Charge Account : Card
Area Feature : gated

Name : Giselle Hamilton
Address : 404 Birch Grove
Phone : 4444444444
Charge Account : Card
Area Feature : townhome